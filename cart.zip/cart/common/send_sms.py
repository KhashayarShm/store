from kavenegar import*
from django.http import HttpResponse

try:
    api = KavenegarAPI('')
    params = {
        'sender': '',#optional
        'receptor': '09122418657',#multiple mobile number, split by comma
        'message': '',
    }
    response = api.sms_send(params)
    print(response)
except APIException as e:
    print(e)
except HTTPException as e:
    print(e)

def send_sms_with_template(receptor,tokens:dict,template):
    try:
      api = KavenegarAPI('')
      params = {
          'receptor': receptor,
          'template': template,
          'type': 'sms',#sms vs call
      }
      for key, value in tokens.items():
          params[key] = value
      response = api.verify_lookup(params)
      print(response)
    except APIException as e:
      print(e)
    except HTTPException as e:
      print(e)
    except UnicodeEncodeError:
        return HttpResponse('thanks')