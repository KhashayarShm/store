from django.urls import path
from . import views
app_name = 'orders'

urlpatterns = [
    path('verify_phone/', views.verify_phone, name='verify_phone'),
    path('verify_code/', views.verify_code, name='verify_code'),
    path('order_created/', views.order_created, name='order_created'),
]