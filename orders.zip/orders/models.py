from django.contrib.auth.models import User
from django.db import models
from shop.models import Product
# Create your models here.

class Order(models.Model):
    first_name = models.CharField(max_length=50,verbose_name='نام')
    last_name = models.CharField(max_length=50,verbose_name='نام خانوادگی')
    phone = models.CharField(max_length=11,verbose_name='تلفن')
    address = models.CharField(max_length=1000,verbose_name='آدرس')
    province = models.CharField(max_length=150,verbose_name='استان')
    city = models.CharField(max_length=150,verbose_name='شهر')
    postal_code = models.CharField(max_length=10,verbose_name='کدپستی')
    created = models.DateTimeField(auto_now_add=True,verbose_name='زمان ایجاد')
    updated = models.DateTimeField(auto_now=True,verbose_name='به روز رسانی')
    paid = models.BooleanField(default=False,verbose_name='پرداخت')

    class Meta:
        ordering = ['-created']
        indexes = [
            models.Index(fields=['created']),
        ]

    def __str__(self):
        return f"order {self.id}"

    def get_total_cost(self):
        return sum(item.get_cost() for item in self.items.all())

    def get_post_cost(self):
        weight=sum(item.get_weight() for item in self.items.all())
        if weight < 2000:
            return 200000
        elif 2000 <= weight <= 10000:
            return 500000
        else:
            return 1000000

    def get_final_price(self):
        price = self.get_post_cost()+self.get_total_cost()
        return price


class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='items',verbose_name='سفارش')
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='order_items',verbose_name='محصول')
    price = models.PositiveIntegerField(default=0,verbose_name='قیمت')
    quantity = models.PositiveIntegerField(default=1,verbose_name='تعداد')
    weight = models.PositiveIntegerField(default=0,verbose_name='وزن')

    def __str__(self):
        return f"{self.id}"

    def get_cost(self):
        return self.price * self.quantity

    def get_weight(self):
        return self.weight