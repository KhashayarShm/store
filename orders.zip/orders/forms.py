from django import forms
from .models import Order
class OrderForm(forms.Form):
    phone = forms.CharField(max_length=11,required=True)

    def clean_phone(self):
        phone = self.cleaned_data['phone']
        if phone.isdigit():
            if '0' in phone[0] and '9' in phone[1]:
                return phone
            else:
                raise forms.ValidationError('Phone number must be entered in the format: 09')
        else:

          raise forms.ValidationError('Phone number must be digit')

class OrderCreationForm(forms.ModelForm):

    class Meta:

        model = Order
        fields = ['phone','address','postal_code','city','province']
