from django.shortcuts import render,redirect
from .models import *
from django.contrib import messages
import random
from cart.common.send_sms import send_sms_with_template
from .forms import *
from accounts.models import ShopUser,Address
from django.contrib.auth import login
from cart.cart import Cart
from django.contrib.auth.decorators import login_required
# Create your views here.
def verify_phone(request):
    if request.user.is_authenticated :
        return redirect('orders:order_created')
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            phone = form.cleaned_data['phone']
            if ShopUser.objects.filter(phone=phone).exists():
                messages.error(request, 'Phone number already exists')
                return redirect('accounts:login')
            else:
                tokens={'token':''.join(random.choices('0123456789',k=6))}
                request.session['verification_token'] = tokens['token']
                request.session['phone'] = phone
                send_sms_with_template(phone,tokens,'welcoming')
                messages.success(request,'Thank you for verifying your phone number')
                return redirect('orders:verify_code')
    else:
        form = OrderForm()
    return render(request,'verify_phone.html',{'form':form})

def verify_code(request):
    if request.method == 'POST':
        code = request.POST['code']
        if code:
            verification_token = request.session['verification_token']
            phone = request.session['phone']
            if code==verification_token:
                user = ShopUser.objects.create(phone=phone)
                user.set_password(''.join(random.choices('0123456789',k=8)))
                user.save()
                print(user.password)
                send_sms_with_template(phone,{'token':user.password},'welcoming')
                login(request,user)
                del request.session['verification_token']
                del request.session['phone']
                return redirect('orders:order_created')
            else:
                messages.error(request,'Invalid code')
    return render(request,'verify_code.html')



@login_required
def order_created(request):
    cart = Cart(request)
    if request.method == 'POST':
        form = OrderCreationForm(request.POST)
        if form.is_valid():
            order = form.save()
            for item in cart:
                OrderItem.objects.create(
                    order=order,
                    product=item['product'],
                    price=item['price'],
                    quantity=item['quantity'],
                    weight=item['weight'],
                )
            cart.clear()
            return redirect('accounts:profile')
    else:
        form = OrderCreationForm()
    return render(request,'order_created.html',{'form':form,'cart':cart})


