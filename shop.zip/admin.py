from django.contrib import admin

from shop.models import *


# Register your models here.

class ImageInline(admin.TabularInline):

    model = Image
    extra = 0
class FeatureInline(admin.TabularInline):

    model = Feature
    extra = 0

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name','slug']
    prepopulated_fields = {'slug':('name',)}

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['name','inventory','category','new_price','updated']
    inlines = [ImageInline,FeatureInline]
    prepopulated_fields = {'slug':('name',)}
    list_filter = ['created','updated']
