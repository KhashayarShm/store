from django.db import models
from django.urls import reverse


# Create your models here.
class Category(models.Model):
    name = models.CharField(max_length=100)
    slug = models.SlugField(max_length=100, unique=True)
    class Meta:
        indexes = [
            models.Index(fields=['name'])
        ]
        verbose_name= 'دسته بندی'
        verbose_name_plural = 'دسته بندی ها'
    def get_absolute_url(self):
        return reverse('shop:products_list_by_category',args=[self.slug])
    def __str__(self):
        return self.name


class Product(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='products',verbose_name='دسته بندی')
    name = models.CharField(max_length=255,verbose_name='نام محصول')
    slug = models.SlugField(max_length=255, unique=True,verbose_name='اسلاگ')
    description = models.TextField(verbose_name='توضیحات')
    inventory= models.PositiveSmallIntegerField(default=0,verbose_name='موجودی')
    price=models.PositiveSmallIntegerField(default=0,verbose_name='قیمت')
    off=models.FloatField(default=0,verbose_name='تخفیف')
    new_price=models.PositiveSmallIntegerField(default=0,verbose_name='قیمت جدید')
    weight=models.PositiveIntegerField(default=0,verbose_name='وزن')
    created = models.DateTimeField(auto_now_add=True,verbose_name='زمان ایجاد')
    updated=models.DateTimeField(auto_now=True,verbose_name='به روز رسانی')
    class Meta:
        ordering = ['-created']
        indexes = [models.Index(fields=['name']),
                   models.Index(fields=['slug','id']),
                   models.Index(fields=['created']),]
        verbose_name='محصول'
        verbose_name_plural ='محصولات'
    def get_absolute_url(self):
        return reverse('shop:product_detail',args=[self.id,self.slug])

    def __str__(self):
            return self.name

class Image(models.Model):
    product=models.ForeignKey(Product,on_delete=models.CASCADE,related_name='images',verbose_name='محصول')
    file=models.ImageField(upload_to="product-image\%Y\%m\%d")
    title=models.CharField(max_length=255,verbose_name='عنوان' ,null=True,blank=True)
    description=models.TextField(verbose_name='توضیحات')
    created = models.DateTimeField(auto_now_add=True, verbose_name='زمان ایجاد')


class Feature(models.Model):
    name=models.CharField(max_length=255,verbose_name="نام ویژگی")
    value=models.CharField(max_length=255,verbose_name="مقدار ویژگی")
    product=models.ForeignKey(Product,related_name='features',on_delete=models.CASCADE,verbose_name='ویژگی ها')
    def __str__(self):
        return self.name + ":" + self.value


