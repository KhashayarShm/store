from django.db.models.signals import pre_save
from django.dispatch import receiver
from .models import Product
@receiver(pre_save, sender=Product)
def product_pre_save_handler(sender, instance, *args, **kwargs):
    instance.new_price=instance.price-instance.off
