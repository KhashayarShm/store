from django.shortcuts import render,get_object_or_404
from .models import Product,Category
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.views.generic import DetailView,ListView
# Create your views here.




def product_list(request,category_slug=None):
    category=None
    categories=Category.objects.all()
    products=Product.objects.all()
    if category_slug:
        category=get_object_or_404(Category,slug=category_slug)
        products=products.filter(category=category)
    # Pagination setup
    paginator = Paginator(products, 2)  # Show 6 products per page
    page = request.GET.get('page')
    try:
        products = paginator.page(page)
    except PageNotAnInteger:
        products = paginator.page(1)
    except EmptyPage:
        products = paginator.page(paginator.num_pages)
    context={
            'category':category,
            'products':products,
            'categories':categories,
        }

    return render(request,'shop/list.html',context)

def product_detail(request,id,slug):
    product=get_object_or_404(Product,id=id,slug=slug)
    context={
        'product':product,
    }
    return render(request,'shop/detail.html',context)


def home(request,category_slug=None):
    category = None
    categories = Category.objects.all()
    products = Product.objects.all()
    if category_slug:
        category = get_object_or_404(Category, slug=category_slug)
        products = products.filter(category=category)
    context = {
        'category': category,
        'products': products,
        'categories': categories,
    }
    return render(request,'themes/shop-four-columns.html',context)


def home_detail(request,id,slug):
    product=get_object_or_404(Product,id=id,slug=slug)
    context={
        'product':product,
    }
    return render(request,'themes/product-details-affiliate.html',context)

