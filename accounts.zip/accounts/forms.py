from django import forms
from .models import ShopUser,Address

class LoginForm(forms.Form):
    phone = forms.CharField(max_length=11,required=True)
    password = forms.CharField(required=True,widget=forms.PasswordInput())

class ShopUserRegisterForm(forms.ModelForm):
    password = forms.CharField(max_length=250,widget=forms.PasswordInput)
    password2 = forms.CharField(max_length=250,widget=forms.PasswordInput)
    class Meta:
        model = ShopUser
        fields =['phone','first_name','last_name','email']

    def clean_password2(self):
        cd = self.cleaned_data
        if cd['password'] != cd['password2']:
            raise forms.ValidationError("Passwords don't match")
        return cd['password2']

class ShopUserEditForm(forms.ModelForm):

    class Meta:
        model = ShopUser
        fields =['first_name','last_name','email']

class AddressEditForm(forms.ModelForm):
    class Meta:
        model = Address
        fields =['address','city','province','postal_code']


