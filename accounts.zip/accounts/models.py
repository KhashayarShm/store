from django.db import models
from django.contrib.auth.models import AbstractUser, BaseUserManager, PermissionsMixin
from django.utils import timezone

# Create your models here.
class ShopUserManager(BaseUserManager):
    def create_user(self, phone, password=None, **extra_fields):
        if not phone:
            raise ValueError("Users must have a Phone number")
        user = self.model(phone=phone, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, phone, password, **extra_fields):

        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)

        if extra_fields.get("is_staff") is not True:
            raise ValueError("Superuser must have is_staff=True.")

        if extra_fields.get("is_superuser") is not True:
            raise ValueError("Superuser must have is_superuser=True.")

        return self.create_user(phone, password, **extra_fields)

class ShopUser(AbstractUser,PermissionsMixin):
    username = None
    phone = models.CharField(max_length=11, unique=True,verbose_name="تلفن")
    first_name = models.CharField(max_length=30, verbose_name="نام")
    last_name = models.CharField(max_length=30, verbose_name="نام خانوادگی")
    email = models.EmailField()
    date_joined=models.DateTimeField(default=timezone.now, verbose_name="تاریخ عضویت")
    content=models.TextField(max_length=180)
    objects = ShopUserManager()
    USERNAME_FIELD = "phone"
    REQUIRED_FIELDS = []
    def __str__(self):
        return self.phone

class Address(models.Model):
    user = models.ForeignKey(ShopUser, on_delete=models.CASCADE,related_name="addresses")
    address = models.CharField(max_length=1000, verbose_name='آدرس')
    province = models.CharField(max_length=150, verbose_name='استان')
    city = models.CharField(max_length=150, verbose_name='شهر')
    postal_code = models.CharField(max_length=10, verbose_name='کدپستی')


    def __str__(self):
        return f"address is {self.province},{self.city},{self.address} for {self.user}"