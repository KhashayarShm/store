from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth import login, authenticate, logout
from .models import *
from django.contrib.auth.decorators import login_required
from .forms import ShopUserRegisterForm, ShopUserEditForm,AddressEditForm,LoginForm
from django.http import JsonResponse
from cart.common.send_sms import *
# Create your views here.
@login_required
def profile(request):
    user = request.user
    info=ShopUser.objects.filter(phone=user.phone)
    return render(request,'profile.html',{'user':user,'info':info})

def login_page(request):
    if request.method == "POST":
        form = LoginForm(request.POST)
        if form.is_valid():
            phone = form.cleaned_data.get('phone')
            password = form.cleaned_data.get('password')
            user = authenticate(username=phone, password=password)
            if user is not None:
                if user.is_active:
                    login(request,user)
                return redirect('accounts:profile')
            else:
                return redirect('accounts:login')
    else:
        form = LoginForm()
    return render(request, 'registration/login.html', {'form':form})
@login_required
def logout_user(request):
    logout(request)
    

def signup(request):
    if request.method == 'POST':
        form = ShopUserRegisterForm(request.POST)
        if form.is_valid():
            user=form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            return render(request,'registration/register_done.html',{'user':user})
    else:
        form = ShopUserRegisterForm()
        return render(request,'registration/register.html',{'form':form})



@login_required
def edit_profile(request):
    if request.method == 'POST':
        form = ShopUserEditForm(request.POST,instance=request.user)
        if form.is_valid() :
            form.save()
            return redirect('accounts:profile')
    else:
        form = ShopUserEditForm(instance=request.user)
    return render(
            request,
            'registration/edit_registration.html',
            {'form':form}
        )


@login_required
def manage_addresses(request):
    addresses = request.user.addresses.all()
    add_form = AddressEditForm()  # ✅ Create the blank form here
    address_forms = [
        {'form': AddressEditForm(instance=addr), 'id': addr.id}
        for addr in addresses
    ]
    return render(request, 'registration/manage_addresses.html', {
        'add_form': add_form,
        'address_forms': address_forms,
        'addresses': addresses,
    })

@login_required
def add_address_ajax(request):
    if request.method == 'POST':
        form = AddressEditForm(request.POST)
        if form.is_valid():
            address = form.save(commit=False)
            address.user = request.user
            address.save()
            return JsonResponse({'success': True, 'message': 'Address added successfully.'})
        return JsonResponse({'success': False, 'errors': form.errors}, status=400)
    return JsonResponse({'success': False, 'message': 'Invalid request method.'}, status=405)


@login_required
def edit_address_ajax(request, address_id):
    address = get_object_or_404(Address, pk=address_id, user=request.user)
    if request.method == 'POST':
        form = AddressEditForm(request.POST, instance=address)
        if form.is_valid():
            form.save()
            return JsonResponse({'success': True, 'message': 'Address updated successfully.'})
        return JsonResponse({'success': False, 'errors': form.errors}, status=400)
    return JsonResponse({'success': False, 'message': 'Invalid request method.'}, status=405)


@login_required
def delete_address_ajax(request, address_id):
    address = get_object_or_404(Address, pk=address_id, user=request.user)
    if request.method == 'POST':
        address.delete()
        return JsonResponse({'success': True, 'message': 'Address deleted successfully.'})
    return JsonResponse({'success': False, 'message': 'Invalid request method.'}, status=405)