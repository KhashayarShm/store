from django.contrib import admin
from .models import *
from django.contrib.auth.admin import UserAdmin
# Register your models here.

class AddressInline(admin.TabularInline):
    model = Address
    fields = ['address', 'city', 'province', 'postal_code']
    extra=0


@admin.register(ShopUser)
class ShopUserAdmin(UserAdmin):
    model = ShopUser
    search_fields = ['phone', 'first_name', 'last_name', 'email']
    list_filter = ['is_staff', 'is_active', 'is_superuser']
    ordering = ['phone']
    list_display = ("phone", "first_name","last_name", "is_staff", "is_active")
    fieldsets = (
        (None, {"fields": ("phone",'password')}),
        ("Personal info", {"fields": ("first_name", "last_name","email")}),
        ("Permissions", {"fields": ("is_staff", "is_active", "is_superuser", "groups", "user_permissions")}),
        ("Important dates", {"fields": ("last_login", "date_joined")}),
    )
    add_fieldsets = (
        (None, {"fields": ("phone",'password1',"password2")}),
        ("Personal info", {"fields": ("first_name","last_name", "email")}),
        ("Permissions", {"fields": ("is_staff", "is_active", "is_superuser", "groups", "user_permissions")}),
        ("Important dates", {"fields": ("last_login", "date_joined")}),
    )
    inlines = [AddressInline]

