from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

app_name = "accounts"
urlpatterns = [
path('', views.profile, name='profile'),
# path('login/', auth_views.LoginView.as_view(), name='login'),
path('login/', views.login_page, name='login'),
# path('logout/', auth_views.LogoutView.as_view(), name='logout'),
path('logout/', views.logout_user, name='logout'),
path('change-password/', auth_views.PasswordChangeView.as_view(success_url='done'), name='change_password'),
path('change-password/done/', auth_views.PasswordChangeDoneView.as_view(), name='change_password_done'),

path('reset-password/', auth_views.PasswordResetView.as_view(success_url='done'), name='password_reset'),
path('reset-password/done/', auth_views.PasswordResetDoneView.as_view(), name='password_reset_done'),
path('reset-password/<uidb64>/<token>/',auth_views.PasswordResetConfirmView.as_view(success_url='/profile/reset-password/complete/'), name='password_reset_confirm'),
path('reset-password/complete/', auth_views.PasswordResetCompleteView.as_view(), name='password_reset_complete'),
path('register/', views.signup, name='register'),
path('edit/', views.edit_profile, name='edit'),
path('addresses/manage/', views.manage_addresses, name='manage_addresses'),
path('addresses/ajax/add/', views.add_address_ajax, name='add_address_ajax'),
path('addresses/ajax/edit/<int:address_id>/', views.edit_address_ajax, name='edit_address_ajax'),
path('addresses/ajax/delete/<int:address_id>/', views.delete_address_ajax, name='delete_address_ajax'),

]